const express = require("express");
const app = express();
const path = require("path");
const port = 8000;

//bulid in middleware
// console.log(path.join(__dirname,"../public"))
const staticPath = path.join(__dirname,"../public");
app.use(express.static(staticPath)); 


// //to set the view engine
// app.set("view engine","hbs");

// app.get("/",(req,res)=>{
//     res.render("..views/index.hbs");
// })

app.get("/",(req,res)=>{
    res.send("hello from express");
})

app.listen(port,()=>{
    console.log(`listing the port no ${port}`)
});